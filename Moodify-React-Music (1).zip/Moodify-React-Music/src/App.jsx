import React, { useEffect, useMemo, useRef, useState } from 'react';

const moodProfiles = {
  happy: { label:'Happy', emoji:'😊', subtitle:'Emas Cerah', accent:'#facc15', glow:'rgba(250,204,21,.22)', feeling:'Euphoric & Energized', audio:'/music/happy.wav', tracks:[['Morning Radiance','Moodify Original'],['Dancing in Tangerine','Moodify Original'],['Pop Euphoria','Moodify Original']] },
  sad: { label:'Sad', emoji:'😢', subtitle:'Indigo Syahdu', accent:'#818cf8', glow:'rgba(129,140,248,.22)', feeling:'Melancholic & Deep', audio:'/music/sad.wav', tracks:[['Rainy Blues','Moodify Original'],['Echoes in the Mist','Moodify Original'],['Forgotten Solitude','Moodify Original']] },
  chill: { label:'Chill', emoji:'😎', subtitle:'Teal Santai', accent:'#00eefc', glow:'rgba(0,238,252,.20)', feeling:'Relaxed & Unbothered', audio:'/music/chill.wav', tracks:[['Celestial Clouds','Moodify Original'],['Coffee Warmth','Moodify Original'],['Quiet Horizons','Moodify Original']] },
  angry: { label:'Angry', emoji:'😡', subtitle:'Crimson Marun', accent:'#dc0d4f', glow:'rgba(220,13,79,.25)', feeling:'Furious & Explosive', audio:'/music/angry.wav', tracks:[['Rage Ignition','Moodify Original'],['Heavy Pulse','Moodify Original'],['No Surrender','Moodify Original']] },
  romantic: { label:'Romantic', emoji:'❤️', subtitle:'Rose Pink', accent:'#ff7f9a', glow:'rgba(255,127,154,.22)', feeling:'Intimate & Tender', audio:'/music/romantic.wav', tracks:[['Under the Starlight','Moodify Original'],['Soft Whisper Kiss','Moodify Original'],['Moonlight Waltz','Moodify Original']] },
  energetic: { label:'Energetic', emoji:'🔥', subtitle:'Amber Menggebu', accent:'#fb923c', glow:'rgba(251,146,60,.25)', feeling:'Super Hyped & Unstoppable', audio:'/music/energetic.wav', tracks:[['Adrenaline Highs','Moodify Original'],['Cyber Surge','Moodify Original'],['Sprint Beyond','Moodify Original']] },
};

const moods = Object.keys(moodProfiles);
const activities = [['Belajar','📚'],['Tidur','🌙'],['Olahraga','⚡'],['Nongkrong','☕'],['Perjalanan','🚗']];
const genres = ['Lo-Fi','Indie Pop','Synthwave','Acoustic','EDM','R&B','Rock','Classical'];

function App() {
  const [name,setName]=useState('');
  const [mood,setMood]=useState('chill');
  const [selectedGenres,setSelectedGenres]=useState(['Lo-Fi','Indie Pop']);
  const [intensity,setIntensity]=useState(48);
  const [duration,setDuration]=useState(45);
  const [activity,setActivity]=useState('Belajar');
  const [isPlaying,setIsPlaying]=useState(false);
  const [progress,setProgress]=useState(0);
  const [volume,setVolume]=useState(82);
  const [generated,setGenerated]=useState(false);
  const [currentTrack,setCurrentTrack]=useState(0);
  const audioRef=useRef(null);

  const profile=moodProfiles[mood];
  const currentTitle=profile.tracks[currentTrack][0];
  const currentArtist=profile.tracks[currentTrack][1];
  const intensityLabel=intensity<35?'Tenang & Halus':intensity>68?'Keras & Dinamis':'Sedang';
  const durationText=useMemo(()=>duration<=30?'⚡ Sesi Singkat & Cepat':duration<=60?'🧠 Rekomendasi Sesi Fokus':'🌿 Deep Immersion & Meditasi',[duration]);

  useEffect(()=>{
    setCurrentTrack(0); setProgress(0); setIsPlaying(false);
    if(audioRef.current){ audioRef.current.pause(); audioRef.current.currentTime=0; }
  },[mood]);

  useEffect(()=>{ if(audioRef.current) audioRef.current.volume=volume/100; },[volume]);

  useEffect(()=>{
    const audio=audioRef.current;
    if(!audio) return;
    const update=()=>setProgress(audio.duration ? (audio.currentTime/audio.duration)*100 : 0);
    const ended=()=>goNext();
    audio.addEventListener('timeupdate',update);
    audio.addEventListener('ended',ended);
    return()=>{audio.removeEventListener('timeupdate',update);audio.removeEventListener('ended',ended);};
  });

  useEffect(()=>{
    const audio=audioRef.current;
    if(!audio) return;
    audio.load();
    audio.volume=volume/100;
    setProgress(0);
    if(isPlaying) audio.play().catch(()=>setIsPlaying(false));
  },[currentTrack]);

  function toggleGenre(genre){setSelectedGenres(old=>old.includes(genre)?old.filter(g=>g!==genre):[...old,genre]);}
  function togglePlay(){
    const audio=audioRef.current; if(!audio)return;
    if(audio.paused) audio.play().then(()=>setIsPlaying(true)).catch(()=>setIsPlaying(false));
    else {audio.pause();setIsPlaying(false);}
  }
  function selectTrack(index,play=true){setCurrentTrack(index);setProgress(0);setIsPlaying(play);}
  function goNext(){selectTrack((currentTrack+1)%profile.tracks.length,true);}
  function goPrevious(){selectTrack((currentTrack-1+profile.tracks.length)%profile.tracks.length,true);}
  function changeProgress(value){const a=audioRef.current;if(a?.duration){a.currentTime=(value/100)*a.duration;setProgress(value);}}
  function randomizeMood(){const next=moods[Math.floor(Math.random()*moods.length)];setMood(next);setActivity(activities[Math.floor(Math.random()*activities.length)][0]);}
  function generatePlaylist(){setGenerated(false);setTimeout(()=>setGenerated(true),250);setIsPlaying(true);setTimeout(()=>audioRef.current?.play().catch(()=>setIsPlaying(false)),300);}
  function timeText(){const a=audioRef.current; if(!a?.currentTime)return '00:00'; const s=Math.floor(a.currentTime); return `00:${String(s%60).padStart(2,'0')}`;}

  return <div className="app" style={{'--accent':profile.accent,'--glow':profile.glow}}>
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <header className="topbar">
      <div className="brand"><div className="brand-icon">♫</div><div><strong>Moodify</strong><span>Your Mood, Your Music</span></div></div>
      <nav><button className="nav-active">Buat Playlist</button><button>Koleksi Saya</button><button>Eksplorasi Mood</button><button>Riwayat</button></nav>
      <div className="quality">🎧 LOCAL AUDIO</div>
    </header>
    <main>
      <div className="meta-row"><span><i/> Algoritma Mood Music • React Edition</span><small>LIVE • PERSONALIZED EXPERIENCE</small></div>
      <div className="layout">
        <section className="form-section">
          <div className="hero-copy"><span className="eyebrow">✨ KURASI BERDASARKAN SUASANA HATI</span><h1>Sesuaikan Musik dengan <em>Suasana Hatimu</em></h1><p>Pilih mood dan preferensi untuk membuat pengalaman musik yang terasa lebih personal.</p></div>
          <div className="form-card">
            <label className="field-label"><span>👤 Nama Lengkap / Panggilan</span><small>Opsional</small></label>
            <input value={name} onChange={e=>setName(e.target.value)} placeholder="mis. Riski"/>
            <div className="section-title"><span>😊 Mood Hari Ini</span><b>{profile.label} Terpilih</b></div>
            <div className="mood-grid">{moods.map(key=>{const item=moodProfiles[key];return <button key={key} className={`mood-btn ${mood===key?'selected':''}`} onClick={()=>setMood(key)} type="button"><span className="mood-emoji">{item.emoji}</span><span><strong>{item.label}</strong><small>{item.subtitle}</small></span>{mood===key&&<i/>}</button>})}</div>
            <div className="section-title"><span>🎵 Genre Musik Pilihan</span><b>{selectedGenres.length} Terpilih</b></div>
            <div className="chips">{genres.map(g=><button key={g} type="button" className={selectedGenres.includes(g)?'chip active':'chip'} onClick={()=>toggleGenre(g)}>{g}</button>)}</div>
            <div className="sliders">
              <div><div className="slider-head"><span>🎚️ Intensitas Suara</span><b>{intensity}% • {intensityLabel}</b></div><input type="range" min="0" max="100" value={intensity} onChange={e=>setIntensity(Number(e.target.value))}/><div className="range-caption"><span>Halus</span><span>Sedang</span><span>Dinamis</span></div></div>
              <div><div className="slider-head"><span>⏱️ Durasi Sesi</span><b>{duration} Menit</b></div><input type="range" min="15" max="180" step="5" value={duration} onChange={e=>setDuration(Number(e.target.value))}/><div className="duration-tag">{durationText}</div></div>
            </div>
            <div className="section-title"><span>🏃 Aktivitas Saat Mendengarkan</span></div>
            <div className="activity-grid">{activities.map(([label,emoji])=><button key={label} type="button" className={activity===label?'activity selected':'activity'} onClick={()=>setActivity(label)}><span>{emoji}</span><small>{label}</small></button>)}</div>
            <div className="actions"><button className="primary-action" onClick={generatePlaylist}>{generated?'✓ Playlist Berhasil Dibuat!':'♫ Buat Playlist Mood'}</button><button className="secondary-action" onClick={randomizeMood}>🎲 Acak Suasana</button></div>
          </div>
        </section>
        <aside className="player-wrap">
          <div className="player-glow"/>
          <div className="player">
            <audio ref={audioRef} src={profile.audio} preload="metadata"/>
            <div className="player-head"><span>♫ MOOD MUSIC</span><small><i/> AUDIO AKTIF</small></div>
            <div className="visualizer"><div className={`vinyl ${isPlaying?'spinning':''}`}><div className="vinyl-center">{profile.emoji}</div></div><h2>{currentTitle}</h2><p>{currentArtist} • Sesi {activity}</p><div className="equalizer">{Array.from({length:14}).map((_,i)=><span key={i} style={{height:`${20+((i*17+mood.length*11)%70)}%`,animationDelay:`${i*.06}s`}}/>)}</div></div>
            <div className="progress-wrap"><input className="progress" type="range" min="0" max="100" value={progress} onChange={e=>changeProgress(Number(e.target.value))}/><div><span>{timeText()}</span><span>00:12</span></div></div>
            <div className="controls"><button type="button">🔀</button><button type="button" onClick={goPrevious}>⏮</button><button type="button" className="play" onClick={togglePlay}>{isPlaying?'Ⅱ':'▶'}</button><button type="button" onClick={goNext}>⏭</button><button type="button">🔁</button></div>
            <div className="volume"><span>🔊</span><input type="range" min="0" max="100" value={volume} onChange={e=>setVolume(Number(e.target.value))}/><small>{volume}%</small></div>
            <div className="feeling"><span>{profile.emoji} Feeling: {profile.feeling}</span><small>● WAV LOCAL</small></div>
            <div className="queue"><label>ANTREAN REKOMENDASI</label>{profile.tracks.map(([title,artist],index)=><button key={title} className={index===currentTrack?'track current':'track'} onClick={()=>selectTrack(index,true)}><span className="track-number">{index===currentTrack?'♫':index+1}</span><span className="track-info"><strong>{title}</strong><small>{artist}</small></span><small>00:12</small></button>)}</div>
            <div className="quote">“Musik yang tepat bisa membuat suasana hati terasa lebih berarti.”</div>
          </div>
        </aside>
      </div>
    </main>
    <footer>© 2026 Moodify • React • Original audio demo • Your Mood, Your Music.</footer>
  </div>;
}

export default App;
